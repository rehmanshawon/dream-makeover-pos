-- MySQL dump 10.13  Distrib 26.7.0, for macos15.7 (arm64)
--
-- Host: 127.0.0.1    Database: dream_makeover
-- ------------------------------------------------------
-- Server version	26.7.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounting_accounts`
--

DROP TABLE IF EXISTS `accounting_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_accounts` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('ASSET','EQUITY','CONTRA_EQUITY','LIABILITY','EXPENSE','REVENUE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounting_accounts_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_accounts`
--

LOCK TABLES `accounting_accounts` WRITE;
/*!40000 ALTER TABLE `accounting_accounts` DISABLE KEYS */;
INSERT INTO `accounting_accounts` VALUES ('00000000-0000-4000-8000-000000000001','CASH','Cash on hand','ASSET',1),('00000000-0000-4000-8000-000000000002','BANK','Business bank','ASSET',1),('00000000-0000-4000-8000-000000000003','OWNER_CAPITAL','Owner capital','EQUITY',1),('00000000-0000-4000-8000-000000000004','OWNER_DRAWINGS','Owner drawings','CONTRA_EQUITY',1),('00000000-0000-4000-8000-000000000005','MOBILE_WALLET','Mobile wallet','ASSET',1),('00000000-0000-4000-8000-000000000006','CARD_CLEARING','Card clearing','ASSET',1),('00000000-0000-4000-8000-000000000007','OTHER_CLEARING','Other payment clearing','ASSET',1),('00000000-0000-4000-8000-000000000008','EXPENSE_ELECTRICITY','Electricity expense','EXPENSE',1),('00000000-0000-4000-8000-000000000009','EXPENSE_WATER','Water expense','EXPENSE',1),('00000000-0000-4000-8000-000000000010','EXPENSE_INTERNET','Internet expense','EXPENSE',1),('00000000-0000-4000-8000-000000000011','EXPENSE_RENT','Rent expense','EXPENSE',1),('00000000-0000-4000-8000-000000000012','EXPENSE_MAINTENANCE','Maintenance expense','EXPENSE',1),('00000000-0000-4000-8000-000000000013','EXPENSE_CLEANING','Cleaning expense','EXPENSE',1),('00000000-0000-4000-8000-000000000014','EXPENSE_STATIONERY','Stationery expense','EXPENSE',1),('00000000-0000-4000-8000-000000000015','EXPENSE_TRANSPORTATION','Transportation expense','EXPENSE',1),('00000000-0000-4000-8000-000000000016','EXPENSE_MARKETING','Marketing expense','EXPENSE',1),('00000000-0000-4000-8000-000000000017','EXPENSE_EQUIPMENT','Equipment expense','EXPENSE',1),('00000000-0000-4000-8000-000000000018','EXPENSE_MISC','Miscellaneous expense','EXPENSE',1),('00000000-0000-4000-8000-000000000019','SALES_REVENUE','Sales revenue','REVENUE',1),('00000000-0000-4000-8000-000000000020','VAT_PAYABLE','VAT payable','LIABILITY',1),('00000000-0000-4000-8000-000000000021','INVENTORY','Inventory asset','ASSET',1),('00000000-0000-4000-8000-000000000022','COST_OF_GOODS_SOLD','Cost of goods sold','EXPENSE',1),('00000000-0000-4000-8000-000000000023','ACCOUNTS_PAYABLE','Supplier payables','LIABILITY',1),('00000000-0000-4000-8000-000000000024','OPENING_BALANCE_EQUITY','Opening balance equity','EQUITY',1),('00000000-0000-4000-8000-000000000025','PAYROLL_EXPENSE','Payroll expense','EXPENSE',1),('00000000-0000-4000-8000-000000000026','EMPLOYEE_ADVANCES','Employee advances','ASSET',1),('00000000-0000-4000-8000-000000000027','INVENTORY_SHRINKAGE','Inventory shrinkage','EXPENSE',1),('00000000-0000-4000-8000-000000000028','INVENTORY_ADJUSTMENT_GAIN','Inventory adjustment gain','REVENUE',1),('00000000-0000-4000-8000-000000000029','SUPPLIER_RETURN_LOSS','Supplier return variance loss','EXPENSE',1),('00000000-0000-4000-8000-000000000030','SUPPLIER_RETURN_GAIN','Supplier return variance gain','REVENUE',1),('00000000-0000-4000-8000-000000000031','INVENTORY_REVALUATION_LOSS','Inventory revaluation loss','EXPENSE',1),('00000000-0000-4000-8000-000000000032','INVENTORY_REVALUATION_GAIN','Inventory revaluation gain','REVENUE',1);
/*!40000 ALTER TABLE `accounting_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_bank_reconciliation_lines`
--

DROP TABLE IF EXISTS `accounting_bank_reconciliation_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_bank_reconciliation_lines` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reconciliation_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `journal_line_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounting_bank_reconciliation_lines_journal_line` (`journal_line_id`),
  KEY `idx_accounting_bank_reconciliation_lines_reconciliation` (`reconciliation_id`),
  CONSTRAINT `fk_accounting_bank_reconciliation_lines_journal_line` FOREIGN KEY (`journal_line_id`) REFERENCES `accounting_journal_lines` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_bank_reconciliation_lines_reconciliation` FOREIGN KEY (`reconciliation_id`) REFERENCES `accounting_bank_reconciliations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_bank_reconciliation_lines`
--

LOCK TABLES `accounting_bank_reconciliation_lines` WRITE;
/*!40000 ALTER TABLE `accounting_bank_reconciliation_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_bank_reconciliation_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_bank_reconciliations`
--

DROP TABLE IF EXISTS `accounting_bank_reconciliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_bank_reconciliations` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statement_date` date NOT NULL,
  `opening_balance_minor` bigint NOT NULL,
  `closing_balance_minor` bigint NOT NULL,
  `cleared_movement_minor` bigint NOT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounting_bank_reconciliations_account_date` (`account_id`,`statement_date`),
  KEY `idx_accounting_bank_reconciliations_date` (`statement_date`),
  CONSTRAINT `fk_accounting_bank_reconciliations_account` FOREIGN KEY (`account_id`) REFERENCES `accounting_accounts` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_bank_reconciliations`
--

LOCK TABLES `accounting_bank_reconciliations` WRITE;
/*!40000 ALTER TABLE `accounting_bank_reconciliations` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_bank_reconciliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_journal_entries`
--

DROP TABLE IF EXISTS `accounting_journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_journal_entries` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_type` enum('OWNER_CONTRIBUTION','OWNER_WITHDRAWAL','CASH_BANK_TRANSFER','EXPENSE_PAYMENT','SALE_RECEIPT','PURCHASE','SUPPLIER_PAYMENT','OPENING_BALANCE','SALARY_PAYMENT','INVENTORY_ADJUSTMENT','SALES_RETURN','SUPPLIER_RETURN','INVENTORY_REVALUATION','JOURNAL_REVERSAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_date` date NOT NULL,
  `memo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `source_expense_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_transaction_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_purchase_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_salary_payment_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_stock_movement_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_supplier_return_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_cost_revaluation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_sales_return_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_reversal_entry_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_expense` (`source_expense_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_transaction` (`source_transaction_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_purchase` (`source_purchase_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_salary_payment` (`source_salary_payment_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_stock_movement` (`source_stock_movement_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_supplier_return` (`source_supplier_return_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_cost_revaluation` (`source_cost_revaluation_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_sales_return` (`source_sales_return_id`),
  UNIQUE KEY `uq_accounting_journal_entries_source_reversal` (`source_reversal_entry_id`),
  KEY `idx_accounting_journal_entries_date` (`entry_date`,`created_at`),
  CONSTRAINT `fk_accounting_journal_entries_cost_revaluation` FOREIGN KEY (`source_cost_revaluation_id`) REFERENCES `inventory_cost_revaluations` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_expense` FOREIGN KEY (`source_expense_id`) REFERENCES `expenses` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_purchase` FOREIGN KEY (`source_purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_salary_payment` FOREIGN KEY (`source_salary_payment_id`) REFERENCES `salary_payments` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_sales_return` FOREIGN KEY (`source_sales_return_id`) REFERENCES `sales_returns` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_source_reversal` FOREIGN KEY (`source_reversal_entry_id`) REFERENCES `accounting_journal_entries` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_stock_movement` FOREIGN KEY (`source_stock_movement_id`) REFERENCES `stock_movements` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_supplier_return` FOREIGN KEY (`source_supplier_return_id`) REFERENCES `supplier_returns` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_entries_transaction` FOREIGN KEY (`source_transaction_id`) REFERENCES `transactions` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_journal_entries`
--

LOCK TABLES `accounting_journal_entries` WRITE;
/*!40000 ALTER TABLE `accounting_journal_entries` DISABLE KEYS */;
INSERT INTO `accounting_journal_entries` VALUES ('00000000-0000-4000-8000-000000000030','OPENING_BALANCE','2026-09-28','Inventory valuation transition adjustment','MIGRATION-1700000000030','system','2026-09-28 20:54:21.631774',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('02202fa9-2b38-4829-9d62-69af3d98f0dc','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0007','DM-20260930-0007','admin','2026-09-30 23:35:53.303595',NULL,'fca398ff-21a9-4653-b1b7-244b15e55206',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('119f9904-8b4f-4ce4-96b5-0b32d819e2b6','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0001','DM-20260930-0001','admin','2026-09-30 18:21:40.686187',NULL,'57915558-aba9-43e3-8e20-5e9d4bf888b1',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9c95c-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0007','DM-20260917-0007','staff','2026-09-17 03:42:19.945358',NULL,'0097abce-86a5-4096-8ec8-53ff784587ce',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9d514-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0010','DM-20260917-0010','staff','2026-09-17 03:45:13.014495',NULL,'0a2e1848-1062-49d2-80b7-b71a75460fad',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9d6cc-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0003','DM-20260916-0003','admin','2026-09-16 23:21:54.389154',NULL,'0e91632d-61c8-49e0-aab5-da1bbd0b9162',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9d7d0-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0005','DM-20260916-0005','admin','2026-09-16 23:26:46.994569',NULL,'0faba69f-209e-4423-b40c-845084c7c791',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9d8ac-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0004','DM-20260916-0004','admin','2026-09-16 23:23:05.986280',NULL,'140d79b5-98c9-4835-aec7-9511ac5e596e',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9d988-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0001','DM-20260916-0001','admin','2026-09-16 22:52:21.171747',NULL,'18285d88-c997-4bff-b3d1-7e1c3bbf986f',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9da50-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-15','POS sale DM-20260915-0001','DM-20260915-0001','admin','2026-09-15 11:37:33.346138',NULL,'1a6acce4-019e-4c82-be76-235eddae29df',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9db18-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0005','DM-20260917-0005','staff','2026-09-17 03:16:38.337704',NULL,'300d132d-9cb8-400f-92f9-7a573b2616dd',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9dbe0-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0006','DM-20260917-0006','staff','2026-09-17 03:27:51.055269',NULL,'35007418-1eed-4619-8aaa-438cd848618c',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9dca8-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-15','POS sale DM-20260915-0002','DM-20260915-0002','admin','2026-09-15 13:20:54.033900',NULL,'3640abf7-9121-414a-841c-e27c0ee04172',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9dd66-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0001','DM-20260917-0001','admin','2026-09-17 00:16:03.287875',NULL,'385fbf72-9db6-4180-b044-147fbc46a473',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9de24-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0004','DM-20260917-0004','staff','2026-09-17 03:13:27.303301',NULL,'55389639-2f4f-41d7-8a25-59d641760726',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9dee2-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0002','DM-20260917-0002','staff','2026-09-17 01:34:55.448102',NULL,'556bdfcd-2618-41ff-86cc-edab327513e1',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9dfaa-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-22','POS sale DM-20260922-0001','DM-20260922-0001','admin','2026-09-22 15:01:30.908343',NULL,'897d80be-00c7-499c-b6b6-cbc5fc454adc',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e05e-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0011','DM-20260917-0011','staff','2026-09-17 04:01:42.965482',NULL,'9b8d49da-148c-4352-ba70-fd04ff6edb8b',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e11c-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0009','DM-20260917-0009','staff','2026-09-17 03:44:27.190115',NULL,'9dbfa181-3b79-4f15-8cff-2d0afce64ccc',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e1da-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0008','DM-20260917-0008','staff','2026-09-17 03:43:00.616677',NULL,'a02d6a81-eb55-4c84-b3eb-2918c3949ba1',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e28e-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0006','DM-20260916-0006','admin','2026-09-16 23:27:41.127211',NULL,'b481eba8-851b-4ad6-80ee-8f2bcae7d1a3',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e34c-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-22','POS sale DM-20260922-0002','DM-20260922-0002','admin','2026-09-22 23:06:35.111071',NULL,'ba96112b-bf7a-4451-b5b2-887fb925994c',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e446-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0008','DM-20260916-0008','admin','2026-09-16 23:44:00.201819',NULL,'bff16f4b-be0e-43eb-baab-1ec512e464de',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e50e-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0007','DM-20260916-0007','admin','2026-09-16 23:28:23.948115',NULL,'d0b189e3-227f-415b-97ee-1ad345bc16e8',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e5c2-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-17','POS sale DM-20260917-0003','DM-20260917-0003','staff','2026-09-17 02:53:37.532158',NULL,'d3e915e4-5e59-40b6-9d46-c6872c79d196',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('36b9e680-bb40-11f1-953f-b5ec7eb40e25','SALE_RECEIPT','2026-09-16','POS sale DM-20260916-0002','DM-20260916-0002','admin','2026-09-16 23:00:27.273139',NULL,'db1d87f7-2a54-4753-9f72-f467e9d25794',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('40e68edd-df96-4624-8940-213e5f5597ab','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0008','DM-20260930-0008','admin','2026-09-30 23:38:47.189351',NULL,'06d30257-aefd-4961-8fd8-6eebf3fa68a5',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('665b56ed-16c4-4c56-bb5d-1ad24e6dde3e','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0006','DM-20260930-0006','admin','2026-09-30 22:23:31.761750',NULL,'2e1c2891-7bfb-427f-97ce-d8e5a0cde2dd',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8b2efb22-6006-4fd9-9305-2fd902386fbc','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0005','DM-20260930-0005','admin','2026-09-30 21:00:00.145944',NULL,'23c6d836-44b5-4781-9101-7d7fb17084ac',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9a097af8-0878-40d6-8161-3425369adf94','INVENTORY_ADJUSTMENT','2026-09-30','damage','f719ac75-b6ed-4f3f-befd-03ac9c6669aa','admin','2026-09-30 19:26:20.316859',NULL,NULL,NULL,NULL,'f719ac75-b6ed-4f3f-befd-03ac9c6669aa',NULL,NULL,NULL,NULL),('a03dba9c-1f9f-402f-b3e3-7623b3feea79','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0004','DM-20260930-0004','admin','2026-09-30 19:51:08.276291',NULL,'82ba4ae8-5d15-45c7-baf8-1cfebfc89d0b',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ae2867b6-67a1-4408-8410-aad2e064cf4c','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0002','DM-20260930-0002','admin','2026-09-30 18:30:14.561111',NULL,'63cddfaf-3006-4efa-bfa9-295cfc7dfd93',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b9d758b8-bc21-11f1-953f-b5ec7eb40e25','SALARY_PAYMENT','2026-09-25','REGULAR - Mim Sultana','02cd1c07-eed4-4cb5-825b-89ae83f57d27','admin','2026-09-25 15:06:57.840186',NULL,NULL,NULL,'02cd1c07-eed4-4cb5-825b-89ae83f57d27',NULL,NULL,NULL,NULL,NULL),('b9d768b2-bc21-11f1-953f-b5ec7eb40e25','SALARY_PAYMENT','2026-09-25','REGULAR - Mim Sultana','8a3da6c8-a739-42f4-904c-469a63aa3180','admin','2026-09-25 15:08:25.066737',NULL,NULL,NULL,'8a3da6c8-a739-42f4-904c-469a63aa3180',NULL,NULL,NULL,NULL,NULL),('f926d082-c78f-478e-95f1-2860d163ff88','SALE_RECEIPT','2026-09-30','POS sale DM-20260930-0003','DM-20260930-0003','admin','2026-09-30 18:35:43.247536',NULL,'184a543d-c015-4e90-bae8-ae573a205264',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f9d5efaf-fc65-4206-b4ab-02282001e642','PURCHASE','2026-09-30','Inventory purchase from rahimuddin','01758448','admin','2026-09-30 19:24:47.468521',NULL,NULL,'7b483c34-3698-4d49-ab0e-e604eaea0191',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `accounting_journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_journal_lines`
--

DROP TABLE IF EXISTS `accounting_journal_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_journal_lines` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `debit_minor` bigint unsigned NOT NULL DEFAULT '0',
  `credit_minor` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_accounting_journal_lines_entry` (`entry_id`),
  KEY `idx_accounting_journal_lines_account` (`account_id`),
  CONSTRAINT `fk_accounting_journal_lines_account` FOREIGN KEY (`account_id`) REFERENCES `accounting_accounts` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_accounting_journal_lines_entry` FOREIGN KEY (`entry_id`) REFERENCES `accounting_journal_entries` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_accounting_journal_line_one_sided` CHECK ((((`debit_minor` = 0) and (`credit_minor` > 0)) or ((`credit_minor` = 0) and (`debit_minor` > 0))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_journal_lines`
--

LOCK TABLES `accounting_journal_lines` WRITE;
/*!40000 ALTER TABLE `accounting_journal_lines` DISABLE KEYS */;
INSERT INTO `accounting_journal_lines` VALUES ('0f15e9a5-0a32-44d5-95bd-8e2a7111a6ce','40e68edd-df96-4624-8940-213e5f5597ab','00000000-0000-4000-8000-000000000019',0,325000),('1f3870ee-a00b-460a-8600-04f36daee060','665b56ed-16c4-4c56-bb5d-1ad24e6dde3e','00000000-0000-4000-8000-000000000019',0,200000),('1f6afeaa-30b5-4735-b834-55bebc03bfcb','9a097af8-0878-40d6-8161-3425369adf94','00000000-0000-4000-8000-000000000021',0,44000),('2a75043d-b8e8-4d1c-9426-2198d9c129fc','a03dba9c-1f9f-402f-b3e3-7623b3feea79','00000000-0000-4000-8000-000000000019',0,280000),('36ba37ac-bb40-11f1-953f-b5ec7eb40e25','36b9c95c-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',250000,0),('36ba4224-bb40-11f1-953f-b5ec7eb40e25','36b9d514-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',240000,0),('36ba43a0-bb40-11f1-953f-b5ec7eb40e25','36b9d6cc-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36ba449a-bb40-11f1-953f-b5ec7eb40e25','36b9d7d0-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36ba4576-bb40-11f1-953f-b5ec7eb40e25','36b9d8ac-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',100000,0),('36ba465c-bb40-11f1-953f-b5ec7eb40e25','36b9d988-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36ba4724-bb40-11f1-953f-b5ec7eb40e25','36b9da50-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',25000,0),('36ba47ec-bb40-11f1-953f-b5ec7eb40e25','36b9db18-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',210000,0),('36ba48be-bb40-11f1-953f-b5ec7eb40e25','36b9dbe0-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',210000,0),('36ba4986-bb40-11f1-953f-b5ec7eb40e25','36b9dca8-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36ba4a80-bb40-11f1-953f-b5ec7eb40e25','36b9dd66-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',616750,0),('36ba4b52-bb40-11f1-953f-b5ec7eb40e25','36b9de24-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',240000,0),('36ba552a-bb40-11f1-953f-b5ec7eb40e25','36b9dee2-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',220000,0),('36ba59a8-bb40-11f1-953f-b5ec7eb40e25','36b9dfaa-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',140000,0),('36ba5bf6-bb40-11f1-953f-b5ec7eb40e25','36b9e05e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',210000,0),('36ba6092-bb40-11f1-953f-b5ec7eb40e25','36b9e11c-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',210000,0),('36ba639e-bb40-11f1-953f-b5ec7eb40e25','36b9e1da-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',260000,0),('36ba64de-bb40-11f1-953f-b5ec7eb40e25','36b9e28e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36ba65b0-bb40-11f1-953f-b5ec7eb40e25','36b9e34c-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',110000,0),('36ba66a0-bb40-11f1-953f-b5ec7eb40e25','36b9e446-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',545000,0),('36ba6790-bb40-11f1-953f-b5ec7eb40e25','36b9e50e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36ba6880-bb40-11f1-953f-b5ec7eb40e25','36b9e5c2-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',240000,0),('36ba6970-bb40-11f1-953f-b5ec7eb40e25','36b9e680-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000001',75000,0),('36bac5be-bb40-11f1-953f-b5ec7eb40e25','36b9c95c-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,250000),('36bac992-bb40-11f1-953f-b5ec7eb40e25','36b9d514-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,240000),('36baca96-bb40-11f1-953f-b5ec7eb40e25','36b9d6cc-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36bacb9a-bb40-11f1-953f-b5ec7eb40e25','36b9d7d0-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36bacc76-bb40-11f1-953f-b5ec7eb40e25','36b9d8ac-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,100000),('36bacd52-bb40-11f1-953f-b5ec7eb40e25','36b9d988-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36bace2e-bb40-11f1-953f-b5ec7eb40e25','36b9da50-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,25000),('36bacf0a-bb40-11f1-953f-b5ec7eb40e25','36b9db18-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,210000),('36bacfdc-bb40-11f1-953f-b5ec7eb40e25','36b9dbe0-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,210000),('36bad0d6-bb40-11f1-953f-b5ec7eb40e25','36b9dca8-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36bad1d0-bb40-11f1-953f-b5ec7eb40e25','36b9dd66-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,535000),('36bad2ca-bb40-11f1-953f-b5ec7eb40e25','36b9de24-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,240000),('36bad3a6-bb40-11f1-953f-b5ec7eb40e25','36b9dee2-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,220000),('36bad482-bb40-11f1-953f-b5ec7eb40e25','36b9dfaa-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,140000),('36bad55e-bb40-11f1-953f-b5ec7eb40e25','36b9e05e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,210000),('36bad694-bb40-11f1-953f-b5ec7eb40e25','36b9e11c-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,210000),('36bad770-bb40-11f1-953f-b5ec7eb40e25','36b9e1da-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,260000),('36bad84c-bb40-11f1-953f-b5ec7eb40e25','36b9e28e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36bad93c-bb40-11f1-953f-b5ec7eb40e25','36b9e34c-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,110000),('36bada18-bb40-11f1-953f-b5ec7eb40e25','36b9e446-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,545000),('36badaf4-bb40-11f1-953f-b5ec7eb40e25','36b9e50e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36badbda-bb40-11f1-953f-b5ec7eb40e25','36b9e5c2-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,240000),('36badcc0-bb40-11f1-953f-b5ec7eb40e25','36b9e680-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000019',0,75000),('36bb0218-bb40-11f1-953f-b5ec7eb40e25','36b9dd66-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000020',0,81750),('49bc9192-da73-41ee-b3e4-505f9e36e3ec','8b2efb22-6006-4fd9-9305-2fd902386fbc','00000000-0000-4000-8000-000000000001',220000,0),('5210a5e5-c0da-4c54-888d-240bd97a1ef1','ae2867b6-67a1-4408-8410-aad2e064cf4c','00000000-0000-4000-8000-000000000019',0,275000),('5b95a3e8-bb4c-11f1-953f-b5ec7eb40e25','36b9d6cc-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95ad8e-bb4c-11f1-953f-b5ec7eb40e25','36b9d7d0-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95add4-bb4c-11f1-953f-b5ec7eb40e25','36b9d8ac-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',44000,0),('5b95ae06-bb4c-11f1-953f-b5ec7eb40e25','36b9d988-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95ae42-bb4c-11f1-953f-b5ec7eb40e25','36b9da50-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95ae92-bb4c-11f1-953f-b5ec7eb40e25','36b9dca8-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95aece-bb4c-11f1-953f-b5ec7eb40e25','36b9dd66-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',372000,0),('5b95af46-bb4c-11f1-953f-b5ec7eb40e25','36b9e28e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95af8c-bb4c-11f1-953f-b5ec7eb40e25','36b9e446-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',372000,0),('5b95afc8-bb4c-11f1-953f-b5ec7eb40e25','36b9e50e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95b00e-bb4c-11f1-953f-b5ec7eb40e25','36b9e680-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000022',22000,0),('5b95b13a-bb4c-11f1-953f-b5ec7eb40e25','36b9d6cc-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b180-bb4c-11f1-953f-b5ec7eb40e25','36b9d7d0-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b1bc-bb4c-11f1-953f-b5ec7eb40e25','36b9d8ac-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,44000),('5b95b1ee-bb4c-11f1-953f-b5ec7eb40e25','36b9d988-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b22a-bb4c-11f1-953f-b5ec7eb40e25','36b9da50-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b270-bb4c-11f1-953f-b5ec7eb40e25','36b9dca8-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b2a2-bb4c-11f1-953f-b5ec7eb40e25','36b9dd66-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,372000),('5b95b31a-bb4c-11f1-953f-b5ec7eb40e25','36b9e28e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b360-bb4c-11f1-953f-b5ec7eb40e25','36b9e446-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,372000),('5b95b39c-bb4c-11f1-953f-b5ec7eb40e25','36b9e50e-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5b95b3d8-bb4c-11f1-953f-b5ec7eb40e25','36b9e680-bb40-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000021',0,22000),('5c0cbcdb-594f-43cb-8900-299232c80031','02202fa9-2b38-4829-9d62-69af3d98f0dc','00000000-0000-4000-8000-000000000001',220000,0),('7be70133-e2c2-4c1f-bd57-ca40898924a7','9a097af8-0878-40d6-8161-3425369adf94','00000000-0000-4000-8000-000000000027',44000,0),('7d1fe4f6-bb4c-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000030','00000000-0000-4000-8000-000000000021',52200000,0),('7d1fe5a0-bb4c-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000030','00000000-0000-4000-8000-000000000024',0,52200000),('8d831c84-8a97-4250-b806-cbc3e2f56de7','a03dba9c-1f9f-402f-b3e3-7623b3feea79','00000000-0000-4000-8000-000000000001',280000,0),('8eb5589d-0c40-4dd2-8d40-82716136e421','02202fa9-2b38-4829-9d62-69af3d98f0dc','00000000-0000-4000-8000-000000000019',0,220000),('9b99d1c0-d9b3-48ba-8fe5-a37f03a83e2d','40e68edd-df96-4624-8940-213e5f5597ab','00000000-0000-4000-8000-000000000001',325000,0),('9f75302a-6603-4843-a794-74aea72e5cdc','119f9904-8b4f-4ce4-96b5-0b32d819e2b6','00000000-0000-4000-8000-000000000019',0,240000),('a4021631-3c01-4bba-bcf3-cce73b60adbc','f926d082-c78f-478e-95f1-2860d163ff88','00000000-0000-4000-8000-000000000019',0,230000),('b15cbcaf-c894-4604-ab9b-fdc55112b20f','f9d5efaf-fc65-4206-b4ab-02282001e642','00000000-0000-4000-8000-000000000021',440000,0),('b9d84c8c-bc21-11f1-953f-b5ec7eb40e25','b9d758b8-bc21-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000025',1500000,0),('b9d84d68-bc21-11f1-953f-b5ec7eb40e25','b9d768b2-bc21-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000025',1500000,0),('b9d84e62-bc21-11f1-953f-b5ec7eb40e25','b9d758b8-bc21-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000002',0,1500000),('b9d84ed0-bc21-11f1-953f-b5ec7eb40e25','b9d768b2-bc21-11f1-953f-b5ec7eb40e25','00000000-0000-4000-8000-000000000005',0,1500000),('c10a2348-4668-4b40-ad05-a4f721d712e7','f9d5efaf-fc65-4206-b4ab-02282001e642','00000000-0000-4000-8000-000000000001',0,440000),('c1e78546-f8c4-470b-9990-c604493a0901','f926d082-c78f-478e-95f1-2860d163ff88','00000000-0000-4000-8000-000000000020',0,36000),('d4187ff0-19d6-44d2-b9c4-318c1ff294b6','8b2efb22-6006-4fd9-9305-2fd902386fbc','00000000-0000-4000-8000-000000000019',0,220000),('d422fdf4-9c93-433c-9373-8000d1e6f21c','665b56ed-16c4-4c56-bb5d-1ad24e6dde3e','00000000-0000-4000-8000-000000000001',200000,0),('e093bf83-cae1-49f3-86e7-3e692c5c45fe','f926d082-c78f-478e-95f1-2860d163ff88','00000000-0000-4000-8000-000000000001',266000,0),('e1cc87c2-eae6-41c2-9c1a-124ecc948698','119f9904-8b4f-4ce4-96b5-0b32d819e2b6','00000000-0000-4000-8000-000000000001',240000,0),('f7ff3794-d6dd-4e71-a0d9-d690e24c6e6b','ae2867b6-67a1-4408-8410-aad2e064cf4c','00000000-0000-4000-8000-000000000001',275000,0);
/*!40000 ALTER TABLE `accounting_journal_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_periods`
--

DROP TABLE IF EXISTS `accounting_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_periods` (
  `period_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `closed_at` datetime(6) DEFAULT NULL,
  `closed_by` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`period_key`),
  CONSTRAINT `chk_accounting_period_key` CHECK (regexp_like(`period_key`,_utf8mb4'^[0-9]{4}-(0[1-9]|1[0-2])$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_periods`
--

LOCK TABLES `accounting_periods` WRITE;
/*!40000 ALTER TABLE `accounting_periods` DISABLE KEYS */;
INSERT INTO `accounting_periods` VALUES ('2026-09',NULL,NULL);
/*!40000 ALTER TABLE `accounting_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_records`
--

DROP TABLE IF EXISTS `attendance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_records` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `status` enum('PRESENT','ABSENT','HALF_DAY','LEAVE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attendance_employee_date` (`employee_id`,`date`),
  KEY `idx_attendance_employee` (`employee_id`),
  KEY `idx_attendance_date` (`date`),
  CONSTRAINT `fk_attendance_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_records`
--

LOCK TABLES `attendance_records` WRITE;
/*!40000 ALTER TABLE `attendance_records` DISABLE KEYS */;
INSERT INTO `attendance_records` VALUES ('025a35ec-2b54-4373-9a97-6fbd94e271c6','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-29','PRESENT',NULL,'admin','2026-09-25 14:54:22.455367','2026-09-25 14:54:22.455367'),('029fb6d3-a369-4cad-b1fe-c9a6572a062e','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-18','PRESENT',NULL,'admin','2026-09-25 14:54:22.395297','2026-09-25 14:54:22.395297'),('072ef157-a611-4ed2-a92f-d7015a6a55b5','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-16','PRESENT',NULL,'admin','2026-09-25 14:54:22.389164','2026-09-25 14:54:22.389164'),('0a64de2c-9aee-4e96-9483-725b12eb6f57','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-22','PRESENT',NULL,'admin','2026-09-25 15:42:16.928084','2026-09-25 15:42:16.928084'),('0ceaabcc-91ce-411c-ae32-100d0fd11a4b','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-26','ABSENT',NULL,'admin','2026-09-28 15:45:18.725459','2026-09-28 15:45:18.725459'),('0f3ca4f4-ea2b-4b11-8ea7-8f3ab9082444','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-11','PRESENT',NULL,'admin','2026-09-25 14:54:22.371930','2026-09-25 14:54:22.371930'),('1083a720-819a-4bb9-a62f-63bfc1fc2273','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-16','PRESENT',NULL,'admin','2026-09-25 15:42:16.879222','2026-09-25 15:42:16.879222'),('13988c65-3ad8-4b80-b2b6-cf882db8ace0','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-14','PRESENT',NULL,'admin','2026-09-25 14:54:22.381387','2026-09-25 14:54:22.381387'),('171a71e8-e248-4172-81b7-a754798d115e','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-13','PRESENT',NULL,'admin','2026-09-25 14:54:22.377847','2026-09-25 14:54:22.377847'),('219e1417-42c0-4d36-942d-980d21bede4d','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-15','PRESENT',NULL,'admin','2026-09-25 14:54:22.385379','2026-09-25 14:54:22.385379'),('2c09c94d-9275-4127-be87-861fe0a80743','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-01','PRESENT',NULL,'admin','2026-09-25 15:41:47.995422','2026-09-25 15:41:47.995422'),('3497218e-aeb2-4b1f-904f-2aace3dfa203','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-28','ABSENT',NULL,'admin','2026-09-28 15:45:18.756599','2026-09-28 15:45:18.756599'),('38573de3-ba63-46bb-9451-73bc19421c54','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-28','PRESENT',NULL,'admin','2026-09-25 14:54:22.451813','2026-09-25 14:54:22.451813'),('430b4cc4-848c-4244-8b6f-f84554ec84d9','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-02','PRESENT',NULL,'admin','2026-09-25 15:41:48.027913','2026-09-25 15:41:48.027913'),('45b06a4b-b024-4031-9d87-e49392d05aa4','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-19','PRESENT',NULL,'admin','2026-09-25 15:42:16.912478','2026-09-25 15:42:16.912478'),('46675b3b-9179-4335-99a2-1da4a637073b','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-07','ABSENT',NULL,'admin','2026-09-25 15:41:48.056702','2026-09-25 15:42:29.000000'),('51ada748-b053-4dc8-ae2a-8516f707bfb5','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-10','PRESENT',NULL,'admin','2026-09-25 15:41:48.063972','2026-09-25 15:41:48.063972'),('54dc51de-b1fb-4654-bb59-0de4ed5bb520','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-27','ABSENT',NULL,'admin','2026-09-28 15:45:18.753761','2026-09-28 15:45:18.753761'),('585fefff-c3f3-41e9-80d9-4fdf8c759ffb','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-09','ABSENT',NULL,'admin','2026-09-25 15:41:48.061362','2026-09-25 15:42:29.000000'),('603ae330-a936-4528-9160-bf9cdcfabe0e','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-13','PRESENT',NULL,'admin','2026-09-25 15:42:16.862562','2026-09-25 15:42:16.862562'),('62a40a39-70f9-4cff-a0c2-13bfd218449f','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-25','PRESENT',NULL,'admin','2026-09-25 14:54:22.441916','2026-09-25 14:54:22.441916'),('64cd947f-06dc-47da-a056-d491f244d21e','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-06','PRESENT',NULL,'admin','2026-09-25 14:54:22.353335','2026-09-25 14:54:22.353335'),('681848bf-9c19-44c5-91ae-068e95641d19','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-15','PRESENT',NULL,'admin','2026-09-25 15:42:16.875161','2026-09-25 15:42:16.875161'),('68c1137f-7a4f-4fce-badf-75fa07a0c548','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-11','PRESENT',NULL,'admin','2026-09-25 15:42:16.832231','2026-09-25 15:42:16.832231'),('72837531-371c-4627-960a-07fee2af6c77','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-06','PRESENT',NULL,'admin','2026-09-25 15:41:48.054603','2026-09-25 15:41:48.054603'),('72a841e7-e72d-48d0-8a67-0fb1905f5bf1','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-31','PRESENT',NULL,'admin','2026-09-25 14:54:22.460919','2026-09-25 14:54:22.460919'),('78b644df-1180-493a-a3e9-a2be5e7d300e','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-10','PRESENT',NULL,'admin','2026-09-25 14:54:22.367723','2026-09-25 14:54:22.367723'),('79987670-c444-433f-a1b3-735a53c794c0','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-19','PRESENT',NULL,'admin','2026-09-25 14:54:22.399767','2026-09-25 14:54:22.399767'),('7aa2383c-56c8-424c-a52b-4aa4d0055522','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-21','PRESENT',NULL,'admin','2026-09-25 15:42:16.923927','2026-09-25 15:42:16.923927'),('84f19d4d-8d28-4bfc-8445-f5aacb6f3281','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-08','PRESENT',NULL,'admin','2026-09-25 14:54:22.361218','2026-09-25 14:54:22.361218'),('885be786-0232-43d0-b2e2-271c72a214b3','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-07','PRESENT',NULL,'admin','2026-09-25 14:54:22.357318','2026-09-25 14:54:22.357318'),('89d8b4e2-a668-481e-8623-50fe2b4e5532','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-24','PRESENT',NULL,'admin','2026-09-25 15:42:16.937306','2026-09-25 15:42:16.937306'),('8aa5936e-e27c-4d2c-849d-8892d523fc6f','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-22','PRESENT',NULL,'admin','2026-09-25 14:54:22.432061','2026-09-25 14:54:22.432061'),('8f7862d0-d4de-42e9-b60b-7d085cff1ea3','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-27','PRESENT',NULL,'admin','2026-09-25 14:54:22.448112','2026-09-25 14:54:22.448112'),('96ab6898-151d-488d-a764-cdaf400b55e4','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-12','PRESENT',NULL,'admin','2026-09-25 14:54:22.374402','2026-09-25 14:54:22.374402'),('971c8e7f-2b73-40c8-81b0-834b8b2d18c0','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-25','PRESENT',NULL,'admin','2026-09-25 15:42:16.941907','2026-09-25 15:42:16.941907'),('9f9f13c2-cc20-4303-8244-2a5509c1e436','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-03','PRESENT',NULL,'admin','2026-09-25 14:54:22.341518','2026-09-25 14:56:32.000000'),('a7216b7c-963c-4bf4-8340-3ed3a08ff998','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-21','PRESENT',NULL,'admin','2026-09-25 14:54:22.427823','2026-09-25 14:54:22.427823'),('acb9f01b-9c86-449b-aa4d-4ec741c5b8cc','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-26','PRESENT',NULL,'admin','2026-09-25 14:54:22.445364','2026-09-25 14:54:22.445364'),('ae552464-1c1e-49ef-bfb9-4634d2b7664a','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-23','PRESENT',NULL,'admin','2026-09-25 15:42:16.933025','2026-09-25 15:42:16.933025'),('ae792873-c07a-4715-9ffb-5ff994243bed','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-30','PRESENT',NULL,'admin','2026-09-25 14:54:22.458615','2026-09-25 14:54:22.458615'),('aef391a5-7f43-4d45-a7da-572a9c42c5d4','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-14','PRESENT',NULL,'admin','2026-09-25 15:42:16.868328','2026-09-25 15:42:16.868328'),('b15373e6-d8a7-4364-9d77-4d18587b649f','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-23','PRESENT',NULL,'admin','2026-09-25 14:54:22.434651','2026-09-25 14:54:22.434651'),('b50e96ca-1927-43c4-a941-29da04222a5a','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-12','PRESENT',NULL,'admin','2026-09-25 15:42:16.844069','2026-09-25 15:42:16.844069'),('bc238cf9-c324-4512-8e4c-821c093d1555','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-08','ABSENT',NULL,'admin','2026-09-25 15:41:48.059289','2026-09-25 15:42:29.000000'),('bc2ca6d5-b7b5-4504-aea3-c1cbc55792bd','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-17','PRESENT',NULL,'admin','2026-09-25 14:54:22.392095','2026-09-25 14:54:22.392095'),('bff82838-504d-42d8-a1aa-8402763921cf','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-02','HALF_DAY',NULL,'admin','2026-09-25 14:54:22.335489','2026-09-25 14:56:32.000000'),('cb1bf423-0cc9-4d98-bbfc-82efdbe01ce9','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-17','PRESENT',NULL,'admin','2026-09-25 15:42:16.887885','2026-09-25 15:42:16.887885'),('d1d286a1-b6b1-4da3-80e7-a04932bdccea','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-09','PRESENT',NULL,'admin','2026-09-25 14:54:22.363958','2026-09-25 14:54:22.363958'),('d3833dbe-9854-4489-96db-77bfeb9784ca','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-04','PRESENT',NULL,'admin','2026-09-25 14:54:22.345676','2026-09-25 14:56:32.000000'),('da064a2f-8c34-431d-8f35-4da661821f68','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-18','PRESENT',NULL,'admin','2026-09-25 15:42:16.906190','2026-09-25 15:42:16.906190'),('e441488b-b099-4afb-a74e-fa476d507ec8','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-04','PRESENT',NULL,'admin','2026-09-25 15:41:48.048191','2026-09-25 15:41:48.048191'),('e5c6c528-8f91-4c06-b69a-d6fcfcba3f8f','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-24','PRESENT',NULL,'admin','2026-09-25 14:54:22.438901','2026-09-25 14:54:22.438901'),('e76e49f4-9acd-4746-8ce7-8e8210ddaf68','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-20','PRESENT',NULL,'admin','2026-09-25 14:54:22.424303','2026-09-25 14:54:22.424303'),('ec2ffb14-ade4-4ef0-9e79-f81c5b8b1f55','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-01','HALF_DAY',NULL,'admin','2026-09-25 14:54:22.320626','2026-09-25 14:56:32.000000'),('ee2a2157-baa6-4939-9cf2-c0ff16312b06','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-20','PRESENT',NULL,'admin','2026-09-25 15:42:16.917199','2026-09-25 15:42:16.917199'),('f25fb4b4-0170-43a0-9c28-f5ba49dfa125','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-01-05','PRESENT',NULL,'admin','2026-09-25 14:54:22.350100','2026-09-25 14:54:22.350100'),('f2892abd-cdeb-4653-bda6-d6049bd73e5b','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-05','PRESENT',NULL,'admin','2026-09-25 15:41:48.051115','2026-09-25 15:41:48.051115'),('fc6cb938-21e4-4340-8c4c-a0e63b8af7e1','7c769600-b866-11f1-aa1b-83f957c9e72b','2026-09-03','PRESENT',NULL,'admin','2026-09-25 15:41:48.044363','2026-09-25 15:41:48.044363');
/*!40000 ALTER TABLE `attendance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` enum('SERVICE','PRODUCT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categories_kind_slug` (`kind`,`slug`),
  KEY `idx_categories_kind` (`kind`),
  KEY `idx_categories_parent` (`parent_id`),
  CONSTRAINT `fk_categories_parent` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES ('f172f146-b1e1-11f1-ac2a-f851aa63f293','Cosmetics','cosmetics','PRODUCT',NULL,0,1,'2026-09-16 21:19:00.176804','2026-09-16 21:19:00.176804'),('f1732260-b1e1-11f1-ac2a-f851aa63f293','Saree','saree','PRODUCT',NULL,1,1,'2026-09-16 21:19:00.176804','2026-09-16 21:19:00.176804'),('f17326c0-b1e1-11f1-ac2a-f851aa63f293','Three-piece','three-piece','PRODUCT',NULL,2,1,'2026-09-16 21:19:00.176804','2026-09-16 21:19:00.176804'),('f17329f4-b1e1-11f1-ac2a-f851aa63f293','Services','services','SERVICE',NULL,0,1,'2026-09-16 21:19:00.176804','2026-09-16 21:19:00.176804');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reward_tier` enum('Silver','Gold','Platinum','Diamond') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Silver',
  `reward_points` int unsigned NOT NULL DEFAULT '0',
  `lifetime_spend_minor` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customers_phone` (`phone_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES ('2c59a1da-6fa5-4b66-a08c-03ea0999d51c','shawon','01736979369','Rampura','Silver',20,200000,'2026-09-30 22:23:10.286739','2026-09-30 22:23:31.000000'),('aae6d71a-2e5a-4edc-bfce-d15d0ec1a64c','Test customer','01711111111',NULL,'Silver',68,1180000,'2026-09-13 13:58:04.396911','2026-09-30 23:38:47.000000');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_minor` bigint unsigned NOT NULL,
  `salary_frequency` enum('MONTHLY','WEEKLY','DAILY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_payment_method` enum('CASH','BANK','MOBILE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `join_date` date NOT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_or_birth_certificate` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_address` text COLLATE utf8mb4_unicode_ci,
  `permanent_address` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `photo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_employees_full_name` (`full_name`),
  KEY `idx_employees_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('7c769600-b866-11f1-aa1b-83f957c9e72b','Asha Rahman','Senior Stylist',3500000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001001','9999000001','Test House 01, Dhanmondi, Dhaka','Test House 01, Mirpur, Dhaka','TEST DATA','/uploads/employees/test-portrait-01.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76bd4c-b866-11f1-aa1b-83f957c9e72b','Nabila Chowdhury','Hair Stylist',3500000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001002','9999000002','Test House 02, Banani, Dhaka','Test House 02, Mohammadpur, Dhaka','TEST DATA','/uploads/employees/test-portrait-02.svg','2026-09-25 04:22:53.951544','2026-09-25 14:34:21.000000'),('7c76be8c-b866-11f1-aa1b-83f957c9e72b','Farzana Akter','Beautician',2800000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001003','9999000003','Test House 03, Banani, Dhaka','Test House 03, Savar, Dhaka','TEST DATA','/uploads/employees/test-portrait-03.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76bf9a-b866-11f1-aa1b-83f957c9e72b','Samira Islam','Makeup Artist',3200000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001004','9999000004','Test House 04, Gulshan, Dhaka','Test House 04, Keraniganj, Dhaka','TEST DATA','/uploads/employees/test-portrait-04.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76c0a8-b866-11f1-aa1b-83f957c9e72b','Tania Ahmed','Nail Technician',2500000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001005','9999000005','Test House 05, Badda, Dhaka','Test House 05, Narayanganj, Dhaka','TEST DATA','/uploads/employees/test-portrait-05.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76c1b6-b866-11f1-aa1b-83f957c9e72b','Rafiq Hasan','Spa Therapist',2700000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001006','9999000006','Test House 06, Tejgaon, Dhaka','Test House 06, Gazipur, Dhaka','TEST DATA','/uploads/employees/test-portrait-06.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76c2e2-b866-11f1-aa1b-83f957c9e72b','Imran Hossain','Receptionist',2200000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001007','9999000007','Test House 07, Lalmatia, Dhaka','Test House 07, Tongi, Dhaka','TEST DATA','/uploads/employees/test-portrait-07.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76c3dc-b866-11f1-aa1b-83f957c9e72b','Nusrat Jahan','Assistant Stylist',3100000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001008','9999000008','Test House 08, Shyamoli, Dhaka','Test House 08, Cumilla, Dhaka','TEST DATA','/uploads/employees/test-portrait-08.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544'),('7c76c4cc-b866-11f1-aa1b-83f957c9e72b','Mim Sultana','Color Specialist',3000000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001009','9999000009','Test House 09, Rampura, Dhaka','Test House 09, Mymensingh, Dhaka','TEST DATA','/uploads/employees/test-portrait-09.svg','2026-09-25 04:22:53.951544','2026-09-25 15:05:10.000000'),('7c76c5c6-b866-11f1-aa1b-83f957c9e72b','Sadia Karim','Salon Manager',4500000,'MONTHLY','CASH','2026-01-01','ACTIVE','01700001010','9999000010','Test House 10, Khilgaon, Dhaka','Test House 10, Chattogram, Dhaka','TEST DATA','/uploads/employees/test-portrait-10.svg','2026-09-25 04:22:53.951544','2026-09-25 04:22:53.951544');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('ELECTRICITY','WATER','INTERNET','RENT','MAINTENANCE','CLEANING','STATIONERY','TRANSPORTATION','MARKETING','EQUIPMENT','MISC') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_minor` bigint unsigned NOT NULL,
  `expense_date` date NOT NULL,
  `payment_method` enum('CASH','BANK','MOBILE','CARD','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `payee` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_expenses_category` (`category`),
  KEY `idx_expenses_expense_date` (`expense_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_cost_revaluations`
--

DROP TABLE IF EXISTS `inventory_cost_revaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_cost_revaluations` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_date` date NOT NULL,
  `stock_snapshot` int unsigned NOT NULL,
  `previous_unit_cost_minor` bigint unsigned NOT NULL,
  `new_unit_cost_minor` bigint unsigned NOT NULL,
  `inventory_value_delta_minor` bigint NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_inventory_cost_revaluations_product_date` (`product_id`,`effective_date`),
  CONSTRAINT `fk_inventory_cost_revaluations_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_cost_revaluations`
--

LOCK TABLES `inventory_cost_revaluations` WRITE;
/*!40000 ALTER TABLE `inventory_cost_revaluations` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_cost_revaluations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_settings`
--

DROP TABLE IF EXISTS `loyalty_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loyalty_settings` (
  `id` tinyint unsigned NOT NULL,
  `earning_spend_minor` bigint unsigned NOT NULL DEFAULT '10000',
  `earning_points` int unsigned NOT NULL DEFAULT '1',
  `tier_settings` json NOT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_loyalty_settings_singleton` CHECK ((`id` = 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_settings`
--

LOCK TABLES `loyalty_settings` WRITE;
/*!40000 ALTER TABLE `loyalty_settings` DISABLE KEYS */;
INSERT INTO `loyalty_settings` VALUES (1,10000,1,'[{\"tier\": \"Silver\", \"redeemPoints\": 50, \"discountMinor\": 5000, \"minimumPoints\": 0}, {\"tier\": \"Gold\", \"redeemPoints\": 0, \"discountMinor\": 0, \"minimumPoints\": 200}, {\"tier\": \"Platinum\", \"redeemPoints\": 0, \"discountMinor\": 0, \"minimumPoints\": 500}, {\"tier\": \"Diamond\", \"redeemPoints\": 0, \"discountMinor\": 0, \"minimumPoints\": 1000}]','2026-09-30 23:37:59.000000');
/*!40000 ALTER TABLE `loyalty_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` bigint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,1700000000000,'CreateCustomersTable1700000000000'),(2,1700000000001,'CreateProductsTable1700000000001'),(3,1700000000002,'CreateServicesTable1700000000002'),(4,1700000000003,'CreateTransactionsTable1700000000003'),(5,1700000000004,'CreateUsersTable1700000000004'),(6,1700000000005,'CreateTransactionItemsTable1700000000005'),(7,1700000000006,'CreatePackagesTable1700000000006'),(8,1700000000007,'CreatePackageItemsTable1700000000007'),(9,1700000000008,'AddPackageIdToTransactionItems1700000000008'),(10,1700000000009,'CreateStockMovementsTable1700000000009'),(11,1700000000010,'CreateEmployeesTable1700000000010'),(12,1700000000011,'CreateSalaryPaymentsTable1700000000011'),(13,1700000000012,'CreateExpensesTable1700000000012'),(14,1700000000013,'CreateCategoriesTable1700000000013'),(15,1700000000014,'AddCategoryIdToProducts1700000000014'),(16,1700000000015,'AddCategoryIdToServices1700000000015'),(17,1700000000016,'AddPackageItemType1700000000016'),(18,1700000000017,'AddVatToTransactions1700000000017'),(19,1700000000016,'CreatePayPeriodsTable1700000000016'),(20,1700000000017,'AddPayPeriodIdToSalaryPayments1700000000017'),(21,1700000000018,'CreateAttendanceTable1700000000018'),(22,1700000000019,'AddDefaultPaymentMethodToEmployees1700000000019'),(23,1700000000020,'ReplacePayPeriodsWithYearMonth1700000000020'),(24,1700000000021,'AddPhotoUrlToEmployees1700000000021'),(25,1700000000022,'AddSalaryPaymentDisbursementDetails1700000000022'),(26,1700000000023,'AddAdvanceAdjustmentPaymentType1700000000023'),(27,1700000000023,'AddAdvanceAdjustmentPaymentType1700000000023'),(28,1700000000024,'AddSalaryPaymentBonusAndOvertimeDetails1700000000024'),(29,1700000000025,'AddEmployeeIdentityAndAddresses1700000000025'),(30,1700000000026,'CreateAccountingJournal1700000000026'),(31,1700000000027,'PostExpensesToAccounting1700000000027'),(32,1700000000028,'PostSalesToAccounting1700000000028'),(33,1700000000029,'AddPurchasesAndCostAccounting1700000000029'),(34,1700000000030,'CompleteInventoryCostAccounting1700000000030'),(35,1700000000031,'PostPayrollPaymentsToAccounting1700000000031'),(36,1700000000032,'PostInventoryAdjustmentsToAccounting1700000000032'),(37,1700000000033,'AddSupplierReturnsAndCostRevaluation1700000000033'),(38,1700000000034,'AddBankReconciliations1700000000034'),(39,1700000000035,'RepairSalesReturnLinesTable1700000000035'),(40,1700000000036,'AddAccountingPeriodControls1700000000036'),(41,1700000000037,'AddAreaToCustomers1700000000037'),(42,1700000000038,'CreateLoyaltySettings1700000000038'),(43,1700000000039,'TrackLoyaltyTransactions1700000000039');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_items`
--

DROP TABLE IF EXISTS `package_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_items` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_kind` enum('SERVICE','PRODUCT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshot_price_minor` bigint unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_package_items_package` (`package_id`),
  KEY `idx_package_items_service` (`service_id`),
  KEY `idx_package_items_product` (`product_id`),
  CONSTRAINT `fk_package_items_package` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_package_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_package_items_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_package_items_kind` CHECK ((((`item_kind` = _utf8mb4'SERVICE') and (`service_id` is not null) and (`product_id` is null)) or ((`item_kind` = _utf8mb4'PRODUCT') and (`product_id` is not null) and (`service_id` is null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_items`
--

LOCK TABLES `package_items` WRITE;
/*!40000 ALTER TABLE `package_items` DISABLE KEYS */;
INSERT INTO `package_items` VALUES ('1f869c94-6a2d-4a5a-9916-db6b0bf92e61','2f2ca549-0f9c-4cb5-8b30-66f7da6060f5','SERVICE','4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,30000,'2026-09-22 12:28:02.609779'),('2d46c8fe-e568-4320-90b4-3c7ae7231aad','2f2ca549-0f9c-4cb5-8b30-66f7da6060f5','SERVICE','aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,50000,'2026-09-22 12:28:02.605829'),('33790858-7360-4601-8124-91110fb9fd37','40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','PRODUCT',NULL,'c07d1989-6a38-4fde-a59d-bedd922a37da',220000,'2026-09-17 00:53:05.795835'),('58b60bf1-c693-4c84-abc2-9a5cadc4bd18','40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','SERVICE','7fb37859-8333-401a-ad69-484b5de50782',NULL,40000,'2026-09-17 00:53:05.792475'),('682ca146-a39c-466f-8314-816a2ec4c727','d682c283-97e7-45ec-bc5b-2d95d27765b2','SERVICE','aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,50000,'2026-09-16 04:26:30.774715'),('729f0881-588e-4e8d-b995-7efb30edb562','d682c283-97e7-45ec-bc5b-2d95d27765b2','PRODUCT',NULL,'f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',25000,'2026-09-16 04:26:30.781999'),('76861290-2afa-4d73-be96-1830205c231e','2f2ca549-0f9c-4cb5-8b30-66f7da6060f5','SERVICE','c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,20000,'2026-09-22 12:28:02.610510'),('831a4fa3-2cef-46c3-b5d6-34f0a38f4c71','40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','SERVICE','c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,20000,'2026-09-17 00:53:05.794928'),('9ab3b331-416f-4f2b-b3c6-5e8d5436bde6','40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','SERVICE','4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,30000,'2026-09-17 00:53:05.789028'),('b4c0bd2a-3de7-4eb2-9dd0-de05acd20a11','40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','SERVICE','aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,50000,'2026-09-17 00:53:05.790947'),('b7ae72f8-6fdd-4bdb-8fa5-2c78412d10ea','40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','SERVICE','d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,100000,'2026-09-17 00:53:05.793983');
/*!40000 ALTER TABLE `package_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `normal_price_minor` bigint unsigned NOT NULL,
  `package_price_minor` bigint unsigned NOT NULL,
  `savings_minor` bigint unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_packages_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES ('2f2ca549-0f9c-4cb5-8b30-66f7da6060f5','Bridal Package2',NULL,100000,90000,10000,1,'2026-09-22 12:28:02.587966','2026-09-22 12:28:02.587966'),('40a0dcc5-4aed-4b3e-ab8e-c57fe7078940','Crystal Radiance',NULL,460000,400000,60000,1,'2026-09-17 00:49:10.719032','2026-09-17 05:42:35.000000'),('d682c283-97e7-45ec-bc5b-2d95d27765b2','Bridal Package',NULL,75000,70000,5000,1,'2026-09-16 04:26:30.757905','2026-09-16 04:26:30.757905');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_periods`
--

DROP TABLE IF EXISTS `pay_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_periods` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` int unsigned NOT NULL,
  `month` tinyint unsigned NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('OPEN','CLOSED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `closed_at` datetime DEFAULT NULL,
  `closed_by` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pay_periods_name` (`name`),
  UNIQUE KEY `uq_pay_periods_year_month` (`year`,`month`),
  KEY `idx_pay_periods_dates` (`start_date`,`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_periods`
--

LOCK TABLES `pay_periods` WRITE;
/*!40000 ALTER TABLE `pay_periods` DISABLE KEYS */;
INSERT INTO `pay_periods` VALUES ('3b217149-d902-48a1-a72f-153655e146f9',2026,10,'October 2026','2026-10-01','2026-10-31','OPEN',NULL,NULL,'2026-10-01 00:00:58.201430','2026-10-01 00:00:58.201430'),('7c76d6d8-b866-11f1-aa1b-83f957c9e72b',2026,1,'January','2026-01-01','2026-01-31','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76d980-b866-11f1-aa1b-83f957c9e72b',2026,2,'February','2026-02-01','2026-02-28','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76dae8-b866-11f1-aa1b-83f957c9e72b',2026,3,'March','2026-03-01','2026-03-31','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76dc32-b866-11f1-aa1b-83f957c9e72b',2026,4,'April','2026-04-01','2026-04-30','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76dd72-b866-11f1-aa1b-83f957c9e72b',2026,5,'May','2026-05-01','2026-05-31','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76dffc-b866-11f1-aa1b-83f957c9e72b',2026,7,'July','2026-07-01','2026-07-31','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76e132-b866-11f1-aa1b-83f957c9e72b',2026,8,'August','2026-08-01','2026-08-31','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('7c76eda8-b866-11f1-aa1b-83f957c9e72b',2026,9,'September','2026-09-01','2026-09-30','OPEN',NULL,NULL,'2026-09-25 04:22:53.953307','2026-09-25 04:22:53.953307'),('d96b7aa5-fab7-4221-ad65-f96ec9223cf7',2026,6,'June 2026','2026-06-01','2026-06-30','OPEN',NULL,NULL,'2026-09-25 14:47:43.680598','2026-09-25 14:47:43.680598');
/*!40000 ALTER TABLE `pay_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int unsigned NOT NULL DEFAULT '0',
  `purchase_cost_minor` bigint unsigned NOT NULL DEFAULT '0',
  `selling_price_minor` bigint unsigned NOT NULL,
  `minimum_stock_threshold` int unsigned NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_products_category` (`category_id`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('65af649e-d5c0-43f5-b91d-a8a12b2eb755','Zamdani','f1732260-b1e1-11f1-ac2a-f851aa63f293',98,200000,250000,10,'2026-09-16 23:43:00.246746','2026-09-17 00:16:03.000000'),('697b0ab9-0f4c-4501-a9bb-bcca195bb979','Zamdani','f1732260-b1e1-11f1-ac2a-f851aa63f293',0,200000,250000,10,'2026-09-30 19:17:26.527405','2026-09-30 19:17:26.527405'),('9ff962ce-767c-4520-95d1-0cb502f7829a','Vaseline Meril','f172f146-b1e1-11f1-ac2a-f851aa63f293',18,22000,30000,10,'2026-09-30 19:22:24.148902','2026-09-30 19:26:20.000000'),('c07d1989-6a38-4fde-a59d-bedd922a37da','Salwar Kamiz','f17326c0-b1e1-11f1-ac2a-f851aa63f293',198,150000,220000,10,'2026-09-16 23:43:40.889569','2026-09-17 00:16:03.000000'),('f81330ad-0b4c-44ac-ace1-ee3fe54f32eb','Rexona Vitamin + Bright','f172f146-b1e1-11f1-ac2a-f851aa63f293',88,22000,25000,5,'2026-09-14 13:39:50.109267','2026-09-17 00:16:03.000000');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_lines`
--

DROP TABLE IF EXISTS `purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_lines` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int unsigned NOT NULL,
  `unit_cost_minor` bigint unsigned NOT NULL,
  `total_cost_minor` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_purchase_lines_purchase` (`purchase_id`),
  KEY `idx_purchase_lines_product` (`product_id`),
  CONSTRAINT `fk_purchase_lines_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_purchase_lines_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_lines`
--

LOCK TABLES `purchase_lines` WRITE;
/*!40000 ALTER TABLE `purchase_lines` DISABLE KEYS */;
INSERT INTO `purchase_lines` VALUES ('6acdc8d0-f489-4eb8-bb14-aa0db8d6f2d8','7b483c34-3698-4d49-ab0e-e604eaea0191','9ff962ce-767c-4520-95d1-0cb502f7829a',20,22000,440000);
/*!40000 ALTER TABLE `purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_date` date NOT NULL,
  `supplier_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` enum('CASH','BANK','MOBILE','CREDIT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_minor` bigint unsigned NOT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_purchases_date` (`purchase_date`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES ('7b483c34-3698-4d49-ab0e-e604eaea0191','2026-09-30','rahimuddin','01758448','CASH',440000,'admin','2026-09-30 19:24:47.371251');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_payments`
--

DROP TABLE IF EXISTS `salary_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salary_payments` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_period_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_minor` bigint unsigned NOT NULL,
  `payment_type` enum('REGULAR','BONUS','OVERTIME','ADVANCE','ADVANCE_ADJUSTMENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REGULAR',
  `payment_method` enum('CASH','BANK','MOBILE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `paid_on` date NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overtime_hours` smallint unsigned DEFAULT NULL,
  `overtime_date` date DEFAULT NULL,
  `check_number` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_wallet_provider` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_wallet_number` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_salary_payments_employee` (`employee_id`),
  KEY `idx_salary_payments_paid_on` (`paid_on`),
  KEY `idx_salary_payments_period` (`pay_period_id`),
  CONSTRAINT `fk_salary_payments_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_salary_payments_period` FOREIGN KEY (`pay_period_id`) REFERENCES `pay_periods` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_payments`
--

LOCK TABLES `salary_payments` WRITE;
/*!40000 ALTER TABLE `salary_payments` DISABLE KEYS */;
INSERT INTO `salary_payments` VALUES ('02cd1c07-eed4-4cb5-825b-89ae83f57d27','7c76c4cc-b866-11f1-aa1b-83f957c9e72b','7c76d6d8-b866-11f1-aa1b-83f957c9e72b',1500000,'REGULAR','BANK','2026-09-25','Salary partially paid.',NULL,NULL,NULL,'dutch95459043854',NULL,NULL,NULL,'admin','2026-09-25 15:06:57.840186'),('8a3da6c8-a739-42f4-904c-469a63aa3180','7c76c4cc-b866-11f1-aa1b-83f957c9e72b','7c76d6d8-b866-11f1-aa1b-83f957c9e72b',1500000,'REGULAR','MOBILE','2026-09-25',NULL,NULL,NULL,NULL,NULL,NULL,'bKash','4654645654','admin','2026-09-25 15:08:25.066737');
/*!40000 ALTER TABLE `salary_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_return_lines`
--

DROP TABLE IF EXISTS `sales_return_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_return_lines` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sales_return_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_item_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int unsigned NOT NULL,
  `gross_minor` bigint unsigned NOT NULL,
  `revenue_reversal_minor` bigint unsigned NOT NULL,
  `vat_reversal_minor` bigint unsigned NOT NULL,
  `refund_minor` bigint unsigned NOT NULL,
  `cogs_reversal_minor` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sales_return_lines_return` (`sales_return_id`),
  KEY `idx_sales_return_lines_item` (`transaction_item_id`),
  KEY `fk_sales_return_lines_product` (`product_id`),
  CONSTRAINT `fk_sales_return_lines_item` FOREIGN KEY (`transaction_item_id`) REFERENCES `transaction_items` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sales_return_lines_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sales_return_lines_return` FOREIGN KEY (`sales_return_id`) REFERENCES `sales_returns` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_return_lines`
--

LOCK TABLES `sales_return_lines` WRITE;
/*!40000 ALTER TABLE `sales_return_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_return_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_returns`
--

DROP TABLE IF EXISTS `sales_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_returns` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_date` date NOT NULL,
  `refund_method` enum('CASH','BANK','MOBILE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `refund_minor` bigint unsigned NOT NULL,
  `revenue_reversal_minor` bigint unsigned NOT NULL,
  `vat_reversal_minor` bigint unsigned NOT NULL,
  `cogs_reversal_minor` bigint unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `reward_points_removed` int unsigned NOT NULL DEFAULT '0',
  `reward_points_restored` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sales_returns_transaction` (`transaction_id`),
  CONSTRAINT `fk_sales_returns_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_returns`
--

LOCK TABLES `sales_returns` WRITE;
/*!40000 ALTER TABLE `sales_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_minor` bigint unsigned NOT NULL,
  `duration_minutes` int unsigned NOT NULL,
  `reward_point_weight` int unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_services_category` (`category_id`),
  CONSTRAINT `fk_services_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES ('4c72bab3-b4e0-498b-b2d6-1c8e899b1c59','Hair Blow Dry','f17329f4-b1e1-11f1-ac2a-f851aa63f293',30000,10,2,1,'2026-09-17 00:42:29.061667','2026-09-17 00:42:29.061667'),('7fb37859-8333-401a-ad69-484b5de50782','Face Booster Serum','f17329f4-b1e1-11f1-ac2a-f851aa63f293',40000,10,2,1,'2026-09-17 00:43:32.490013','2026-09-17 00:43:32.490013'),('aebe058f-8ab3-49e8-8a79-ae9f1a30b97f','Bridal Facial','f17329f4-b1e1-11f1-ac2a-f851aa63f293',50000,60,1,1,'2026-09-15 13:19:53.105109','2026-09-16 21:19:00.354576'),('c7bf60b5-19db-4820-a4a1-b14fb8e71064','Hair Shampoo','f17329f4-b1e1-11f1-ac2a-f851aa63f293',20000,10,1,1,'2026-09-17 00:42:55.714971','2026-09-17 00:42:55.714971'),('d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2','Hydra Facial','f17329f4-b1e1-11f1-ac2a-f851aa63f293',100000,20,5,1,'2026-09-17 00:41:31.202513','2026-09-17 00:41:31.202513');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delta` int NOT NULL,
  `reason` enum('SALE','STOCK_IN','ADJUSTMENT','RETURN','PURCHASE','SUPPLIER_RETURN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_stock_movements_product` (`product_id`),
  KEY `idx_stock_movements_reason` (`reason`),
  KEY `idx_stock_movements_created_at` (`created_at`),
  CONSTRAINT `fk_stock_movements_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES ('11bdac35-8ee7-428a-a01f-5858fdfa29eb','65af649e-d5c0-43f5-b91d-a8a12b2eb755',-1,'SALE','385fbf72-9db6-4180-b044-147fbc46a473',NULL,'admin','2026-09-17 00:16:03.317746'),('17c3e9b7-f719-4e78-b2d2-56bca9a9bb4f','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','0faba69f-209e-4423-b40c-845084c7c791',NULL,'admin','2026-09-16 23:26:47.014347'),('2810ba04-4d24-429e-896e-6980d4fabe2c','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','3640abf7-9121-414a-841c-e27c0ee04172',NULL,'admin','2026-09-15 13:20:54.072200'),('2a72069d-9501-49d6-a9b6-95423778fdd4','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-2,'SALE','140d79b5-98c9-4835-aec7-9511ac5e596e',NULL,'admin','2026-09-16 23:23:05.999159'),('3cdc7ee0-bfdc-44f1-8b48-a8d5acf13f61','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','db1d87f7-2a54-4753-9f72-f467e9d25794',NULL,'admin','2026-09-16 23:00:27.297152'),('423d471d-f709-4c07-840b-33d99aad49d1','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','18285d88-c997-4bff-b3d1-7e1c3bbf986f',NULL,'admin','2026-09-16 22:52:21.238990'),('66c15c16-d064-40e0-9ad1-fbcc2ea8e63d','c07d1989-6a38-4fde-a59d-bedd922a37da',-1,'SALE','385fbf72-9db6-4180-b044-147fbc46a473',NULL,'admin','2026-09-17 00:16:03.320550'),('72cdbd94-1f6c-4517-9857-8182a0090799','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','1a6acce4-019e-4c82-be76-235eddae29df',NULL,'admin','2026-09-15 11:37:33.389685'),('84fd1f00-efe5-4f3c-a534-f216523f5bd8','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','bff16f4b-be0e-43eb-baab-1ec512e464de',NULL,'admin','2026-09-16 23:44:00.227707'),('85d1ae55-4f44-4441-b4a3-79f12e2f6e61','65af649e-d5c0-43f5-b91d-a8a12b2eb755',-1,'SALE','bff16f4b-be0e-43eb-baab-1ec512e464de',NULL,'admin','2026-09-16 23:44:00.233178'),('9cfdeb87-18b9-43eb-82de-4bcdbf98644f','c07d1989-6a38-4fde-a59d-bedd922a37da',-1,'SALE','bff16f4b-be0e-43eb-baab-1ec512e464de',NULL,'admin','2026-09-16 23:44:00.236957'),('a1eb189c-9183-4776-9b49-6ca5a339e16a','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','0e91632d-61c8-49e0-aab5-da1bbd0b9162',NULL,'admin','2026-09-16 23:21:54.425291'),('a96e4e9d-f394-432e-b079-9c105c8ca012','9ff962ce-767c-4520-95d1-0cb502f7829a',20,'PURCHASE','7b483c34-3698-4d49-ab0e-e604eaea0191','Purchase unit cost 22000','admin','2026-09-30 19:24:47.453066'),('b29399d7-2a09-48c5-adfd-a07a7716da72','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','d0b189e3-227f-415b-97ee-1ad345bc16e8',NULL,'admin','2026-09-16 23:28:23.959495'),('e1f2715f-d781-4537-9e86-5f1a6995c76e','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','385fbf72-9db6-4180-b044-147fbc46a473',NULL,'admin','2026-09-17 00:16:03.313937'),('f4d848c8-4faf-4dc4-bf30-9aaeb2649000','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',-1,'SALE','b481eba8-851b-4ad6-80ee-8f2bcae7d1a3',NULL,'admin','2026-09-16 23:27:41.143628'),('f719ac75-b6ed-4f3f-befd-03ac9c6669aa','9ff962ce-767c-4520-95d1-0cb502f7829a',-2,'ADJUSTMENT',NULL,'damage','admin','2026-09-30 19:26:20.308040');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_return_lines`
--

DROP TABLE IF EXISTS `supplier_return_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_return_lines` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_return_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_line_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int unsigned NOT NULL,
  `supplier_credit_minor` bigint unsigned NOT NULL,
  `inventory_value_minor` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_supplier_return_lines_return` (`supplier_return_id`),
  KEY `idx_supplier_return_lines_purchase_line` (`purchase_line_id`),
  KEY `fk_supplier_return_lines_product` (`product_id`),
  CONSTRAINT `fk_supplier_return_lines_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_supplier_return_lines_purchase_line` FOREIGN KEY (`purchase_line_id`) REFERENCES `purchase_lines` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_supplier_return_lines_return` FOREIGN KEY (`supplier_return_id`) REFERENCES `supplier_returns` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_return_lines`
--

LOCK TABLES `supplier_return_lines` WRITE;
/*!40000 ALTER TABLE `supplier_return_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_return_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_returns`
--

DROP TABLE IF EXISTS `supplier_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_returns` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_date` date NOT NULL,
  `supplier_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refund_method` enum('CASH','BANK','MOBILE','CREDIT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit_minor` bigint unsigned NOT NULL,
  `inventory_value_minor` bigint unsigned NOT NULL,
  `variance_minor` bigint unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_supplier_returns_purchase` (`purchase_id`),
  KEY `idx_supplier_returns_date` (`return_date`),
  CONSTRAINT `fk_supplier_returns_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_returns`
--

LOCK TABLES `supplier_returns` WRITE;
/*!40000 ALTER TABLE `supplier_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_items`
--

DROP TABLE IF EXISTS `transaction_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_items` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_type` enum('PRODUCT','SERVICE','PACKAGE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int unsigned NOT NULL,
  `unit_price_minor` bigint unsigned NOT NULL,
  `total_price_minor` bigint unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `cost_of_goods_sold_minor` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_items_transaction` (`transaction_id`),
  KEY `idx_transaction_items_product` (`product_id`),
  KEY `idx_transaction_items_service` (`service_id`),
  KEY `idx_transaction_items_package` (`package_id`),
  CONSTRAINT `fk_transaction_items_package` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_transaction_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_transaction_items_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_transaction_items_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_items`
--

LOCK TABLES `transaction_items` WRITE;
/*!40000 ALTER TABLE `transaction_items` DISABLE KEYS */;
INSERT INTO `transaction_items` VALUES ('0054a295-54f6-4a5f-bb94-dd13346f92f8','556bdfcd-2618-41ff-86cc-edab327513e1',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 01:34:55.464691',0),('02504d53-2b34-48f4-8e02-d436885edc58','897d80be-00c7-499c-b6b6-cbc5fc454adc',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-22 15:01:30.924348',0),('09c8c8f2-f936-4a14-88a5-b8cb9addd99b','556bdfcd-2618-41ff-86cc-edab327513e1',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 01:34:55.461766',0),('0adc185d-8d46-4eb6-bd8d-df86fc49278c','2e1c2891-7bfb-427f-97ce-d8e5a0cde2dd',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 22:23:31.727200',0),('0c3f9afb-d425-43ca-bec9-c5b417cef572','82ba4ae8-5d15-45c7-baf8-1cfebfc89d0b',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 19:51:08.240365',0),('0ce3f056-0121-4ec7-b452-a642887cef82','b481eba8-851b-4ad6-80ee-8f2bcae7d1a3',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:27:41.136101',0),('1062e053-7fb6-4a08-8e9d-c3a0f65b50ea','23c6d836-44b5-4781-9101-7d7fb17084ac',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-30 21:00:00.110970',0),('116c478a-215c-4636-9c4b-ab96c279fd19','a02d6a81-eb55-4c84-b3eb-2918c3949ba1',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',2,50000,100000,'2026-09-17 03:43:00.620420',0),('11f68904-8d14-48b5-8284-166e848a4a85','ba96112b-bf7a-4451-b5b2-887fb925994c',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-22 23:06:35.128540',0),('148e6f5f-0404-4acf-a284-9dc48a6fb8c6','897d80be-00c7-499c-b6b6-cbc5fc454adc',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-22 15:01:30.929197',0),('14a065dc-a14d-4ffb-b881-b355a4ec22cc','06d30257-aefd-4961-8fd8-6eebf3fa68a5',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 23:38:47.177310',0),('14c495ce-9dee-4601-86c7-bdba2717f56e','9dbfa181-3b79-4f15-8cff-2d0afce64ccc',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:44:27.197866',0),('19a508e9-2a0b-40b7-bc3b-b7e616826b04','57915558-aba9-43e3-8e20-5e9d4bf888b1',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 18:21:40.653723',0),('1ba65e95-ac67-436c-b04a-1cd384db21ad','2e1c2891-7bfb-427f-97ce-d8e5a0cde2dd',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 22:23:31.724524',0),('1c764593-3679-4cb3-9195-7293ecefd328','b481eba8-851b-4ad6-80ee-8f2bcae7d1a3','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 23:27:41.133134',22000),('1d32e215-736f-4700-939c-5100c09947e3','d3e915e4-5e59-40b6-9d46-c6872c79d196',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 02:53:37.554042',0),('1f5f276f-c572-491f-b04f-4053c2c1fe3e','bff16f4b-be0e-43eb-baab-1ec512e464de','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 23:44:00.213146',22000),('22580769-ac8c-459e-97ea-59eba26e89bf','300d132d-9cb8-400f-92f9-7a573b2616dd',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 03:16:38.341062',0),('2624eeb8-3c93-44ad-8f65-23ac3268081c','140d79b5-98c9-4835-aec7-9511ac5e596e','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',2,25000,50000,'2026-09-16 23:23:05.992342',44000),('26eb9627-6ec6-4b3e-b942-2f7b88bda06b','0a2e1848-1062-49d2-80b7-b71a75460fad',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-17 03:45:13.025013',0),('2762c345-f78a-40f3-a14d-2adc765616b7','fca398ff-21a9-4653-b1b7-244b15e55206',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 23:35:53.268209',0),('27fa4d08-d4a4-4c86-a317-6e7aba190938','55389639-2f4f-41d7-8a25-59d641760726',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 03:13:27.324086',0),('2a1b4bb3-0063-464c-9714-f545881c645d','0097abce-86a5-4096-8ec8-53ff784587ce',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 03:42:19.956237',0),('2d756f5f-e578-4634-9f3b-3ca813f51188','18285d88-c997-4bff-b3d1-7e1c3bbf986f','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 22:52:21.197313',22000),('319aa028-e9c0-47e7-a1b3-12d8b3ea6f42','bff16f4b-be0e-43eb-baab-1ec512e464de',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:44:00.208416',0),('3541477a-01b1-4830-b73b-9841046d7cd9','385fbf72-9db6-4180-b044-147fbc46a473',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 00:16:03.292546',0),('354a0dd1-a816-4cea-8ee1-53c97702b1a8','d3e915e4-5e59-40b6-9d46-c6872c79d196',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 02:53:37.551073',0),('444edd2f-2b63-42ad-9d9e-0a74c428b8c1','385fbf72-9db6-4180-b044-147fbc46a473','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-17 00:16:03.303277',22000),('45ce61b0-e65c-4c9b-b13b-f7eb68e1c6ec','300d132d-9cb8-400f-92f9-7a573b2616dd',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:16:38.343584',0),('4894a9e6-287a-4760-a9c2-f7e97c087d81','9dbfa181-3b79-4f15-8cff-2d0afce64ccc',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:44:27.198670',0),('4c1d0564-70a3-418b-9a34-52a4d1959b17','db1d87f7-2a54-4753-9f72-f467e9d25794','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 23:00:27.289148',22000),('4c97e620-7401-423c-9393-106ba69fa792','3640abf7-9121-414a-841c-e27c0ee04172','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-15 13:20:54.053882',22000),('5262a533-e2e8-4f1b-b4ab-4f4bc62e362f','57915558-aba9-43e3-8e20-5e9d4bf888b1',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-30 18:21:40.655408',0),('536e6556-0c37-4298-a7ed-db28b516dac3','06d30257-aefd-4961-8fd8-6eebf3fa68a5',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',2,40000,80000,'2026-09-30 23:38:47.173192',0),('56060dac-62f3-45d8-bdad-fd061755de14','140d79b5-98c9-4835-aec7-9511ac5e596e',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:23:05.994063',0),('5a0bd8a8-843c-4e19-9bdb-98295a0322eb','18285d88-c997-4bff-b3d1-7e1c3bbf986f',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 22:52:21.193276',0),('5a7c1a1f-f6bf-4873-8407-418c7c0c3e06','d0b189e3-227f-415b-97ee-1ad345bc16e8','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 23:28:23.952836',22000),('5b3475aa-8632-4c48-8474-7a94ba7ab8e0','55389639-2f4f-41d7-8a25-59d641760726',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:13:27.329169',0),('5ce3bf09-c95e-4b8f-b62c-7324d4180289','35007418-1eed-4619-8aaa-438cd848618c',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 03:27:51.069565',0),('5f844248-ee68-46f0-a714-6a9b6528aa82','d3e915e4-5e59-40b6-9d46-c6872c79d196',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 02:53:37.558808',0),('651a7e60-d8a5-43ee-9771-71bc30cae95c','63cddfaf-3006-4efa-bfa9-295cfc7dfd93',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 18:30:14.531452',0),('66438849-9c7f-4028-b0e9-788bd6276028','300d132d-9cb8-400f-92f9-7a573b2616dd',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:16:38.342319',0),('6903c73b-15fe-40ba-bbe5-17d0ceb02f3e','184a543d-c015-4e90-bae8-ae573a205264',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-30 18:35:43.226862',0),('6a689cbb-8f04-4078-adf2-0cecec1c3729','556bdfcd-2618-41ff-86cc-edab327513e1',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 01:34:55.467128',0),('6de439c1-87f3-458d-85b2-bbfac23de144','0097abce-86a5-4096-8ec8-53ff784587ce',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:42:19.962439',0),('7040729b-5fa7-4dee-9030-1c4ee429812e','9dbfa181-3b79-4f15-8cff-2d0afce64ccc',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 03:44:27.192510',0),('707fc509-f8ba-40a3-9655-f2e6275f8d27','db1d87f7-2a54-4753-9f72-f467e9d25794',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:00:27.285928',0),('70b074ac-e1d9-4b1c-a81b-d92fbe2ba788','0e91632d-61c8-49e0-aab5-da1bbd0b9162','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 23:21:54.410718',22000),('73127360-7f5d-4ebc-a1fd-eaeacbb692ec','0097abce-86a5-4096-8ec8-53ff784587ce',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:42:19.964258',0),('731d8682-9559-4c65-9195-dfc01c85736e','35007418-1eed-4619-8aaa-438cd848618c',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 03:27:51.067410',0),('7877cedc-67e5-4ac4-8813-2ed6dcda1e8c','897d80be-00c7-499c-b6b6-cbc5fc454adc',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-22 15:01:30.927619',0),('80549bda-c53b-40b8-a06e-02205f2fccb4','556bdfcd-2618-41ff-86cc-edab327513e1',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-17 01:34:55.465878',0),('81f0d763-64ad-4aa4-bd4a-edac80f8c5b3','0a2e1848-1062-49d2-80b7-b71a75460fad',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 03:45:13.019874',0),('86df8a55-c504-4b31-941f-bf33202d360e','63cddfaf-3006-4efa-bfa9-295cfc7dfd93',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-30 18:30:14.537487',0),('8740f6a3-31ab-4923-9e19-ddc1dd4cf276','82ba4ae8-5d15-45c7-baf8-1cfebfc89d0b',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-30 19:51:08.245014',0),('897e07f9-e63b-4e25-968e-25383e70c2f9','d0b189e3-227f-415b-97ee-1ad345bc16e8',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:28:23.950041',0),('8bf3847e-35d6-4fd9-806b-dbc9290182d7','a02d6a81-eb55-4c84-b3eb-2918c3949ba1',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:43:00.625073',0),('8d62a326-2794-4777-b7db-cfdc48ce92a6','0a2e1848-1062-49d2-80b7-b71a75460fad',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 03:45:13.017844',0),('9741bb05-dd68-4c97-8950-9aa688761a24','184a543d-c015-4e90-bae8-ae573a205264',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-30 18:35:43.228587',0),('98548146-c8ae-44db-9f35-9d7036994a9e','9b8d49da-148c-4352-ba70-fd04ff6edb8b',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 04:01:42.983949',0),('98b3ad91-695f-4273-9efc-212a1ea9c828','23c6d836-44b5-4781-9101-7d7fb17084ac',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-30 21:00:00.114184',0),('98d8a800-947f-44b3-9349-870fd801d5ad','300d132d-9cb8-400f-92f9-7a573b2616dd',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 03:16:38.339202',0),('99f8aaf0-6750-43e8-a464-9273d722ff78','fca398ff-21a9-4653-b1b7-244b15e55206',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-30 23:35:53.274641',0),('9be13cf9-edc0-424c-8a8d-14f72dfdc382','184a543d-c015-4e90-bae8-ae573a205264',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 18:35:43.229953',0),('9d187f4f-82a4-4490-86ed-541e9e5ac6a7','23c6d836-44b5-4781-9101-7d7fb17084ac',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 21:00:00.108819',0),('9d734a28-274e-4280-8abc-876a5996cbe4','385fbf72-9db6-4180-b044-147fbc46a473','65af649e-d5c0-43f5-b91d-a8a12b2eb755',NULL,NULL,'PRODUCT','Zamdani',1,250000,250000,'2026-09-17 00:16:03.304614',200000),('9feedfec-81e8-481c-a129-a3b495db0a22','a02d6a81-eb55-4c84-b3eb-2918c3949ba1',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:43:00.623647',0),('a3754dd6-e7ee-4578-8ff6-72b8d190cc6c','06d30257-aefd-4961-8fd8-6eebf3fa68a5',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-30 23:38:47.178446',0),('a39c0381-a108-4683-97d5-0aea3880aee0','9dbfa181-3b79-4f15-8cff-2d0afce64ccc',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 03:44:27.194701',0),('a3f38b6d-6f03-4611-9d31-141de7aae9c0','0e91632d-61c8-49e0-aab5-da1bbd0b9162',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:21:54.405958',0),('a4ccff5e-7e75-408b-9bd9-f642f2fb66ab','9b8d49da-148c-4352-ba70-fd04ff6edb8b',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 04:01:42.982307',0),('a5c84353-2699-47f4-bdac-66eac7b2dd5c','55389639-2f4f-41d7-8a25-59d641760726',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-17 03:13:27.330225',0),('afbda03a-b041-42e3-ba7a-0cba5db7e4ad','2e1c2891-7bfb-427f-97ce-d8e5a0cde2dd',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-30 22:23:31.718985',0),('b4f92f30-73d1-48b7-8804-a8ded7e0cd41','63cddfaf-3006-4efa-bfa9-295cfc7dfd93',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-30 18:30:14.539711',0),('b93bf974-25e5-431e-8d58-85ae95cb692b','23c6d836-44b5-4781-9101-7d7fb17084ac',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 21:00:00.098589',0),('bc7bbc6a-7ba8-42f3-b178-7446e3f5c4cd','57915558-aba9-43e3-8e20-5e9d4bf888b1',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-30 18:21:40.651545',0),('bf37890b-24b8-44dd-932a-ab6e3f9c5746','d3e915e4-5e59-40b6-9d46-c6872c79d196',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 02:53:37.557366',0),('c3cea4c3-48d1-401a-9129-0542dc3999a0','06d30257-aefd-4961-8fd8-6eebf3fa68a5',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',2,50000,100000,'2026-09-30 23:38:47.168398',0),('c3f3b6ae-49ae-4761-a4df-3201b1ce6147','3640abf7-9121-414a-841c-e27c0ee04172',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-15 13:20:54.038372',0),('cf743eac-62e6-4098-9aff-ac989504bbd5','fca398ff-21a9-4653-b1b7-244b15e55206',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 23:35:53.275887',0),('cfea91bb-70da-4665-a6e5-b928b5e3b86d','bff16f4b-be0e-43eb-baab-1ec512e464de','c07d1989-6a38-4fde-a59d-bedd922a37da',NULL,NULL,'PRODUCT','Salwar Kamiz',1,220000,220000,'2026-09-16 23:44:00.217050',150000),('cfff6ff9-2608-4be4-a264-a91a7375a32d','fca398ff-21a9-4653-b1b7-244b15e55206',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-30 23:35:53.272960',0),('d031e8f5-4c26-47f5-9b74-1e5307c39e54','ba96112b-bf7a-4451-b5b2-887fb925994c',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-22 23:06:35.126838',0),('d4889b0e-a0b0-44ee-bf42-bf21613fdc03','9b8d49da-148c-4352-ba70-fd04ff6edb8b',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 04:01:42.983122',0),('d7d58080-1c06-407d-8c53-80055ce1877d','0faba69f-209e-4423-b40c-845084c7c791',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-16 23:26:47.002893',0),('d8fdd0ef-a117-4743-9966-7053e441cbc5','57915558-aba9-43e3-8e20-5e9d4bf888b1',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-30 18:21:40.657751',0),('dbd69515-936d-4b00-ad7b-7f1dab59b8ff','35007418-1eed-4619-8aaa-438cd848618c',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:27:51.073967',0),('dbf06975-b70f-45d9-ab5c-a4f31af11bf5','184a543d-c015-4e90-bae8-ae573a205264',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 18:35:43.221695',0),('dca6e1ba-5382-4c59-87fe-bd3ff23e0a65','63cddfaf-3006-4efa-bfa9-295cfc7dfd93',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-30 18:30:14.538591',0),('e0ea4676-e71d-4535-bb15-0e2d778a8503','57915558-aba9-43e3-8e20-5e9d4bf888b1',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-30 18:21:40.643297',0),('e101e80b-c453-4585-994b-7c41b3c0d899','0faba69f-209e-4423-b40c-845084c7c791','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-16 23:26:47.006669',22000),('e2751141-ce2a-4fc4-821d-29bfe23a7331','0a2e1848-1062-49d2-80b7-b71a75460fad',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:45:13.023532',0),('e52e91c3-ade4-470f-8f6d-d9782fc3437d','23c6d836-44b5-4781-9101-7d7fb17084ac',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-30 21:00:00.106559',0),('e751cde7-e6ee-49e8-9f4f-cef583e8f8e2','2e1c2891-7bfb-427f-97ce-d8e5a0cde2dd',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-30 22:23:31.728794',0),('e8b16cde-3c35-4c33-82f1-959f4b9a64a4','385fbf72-9db6-4180-b044-147fbc46a473','c07d1989-6a38-4fde-a59d-bedd922a37da',NULL,NULL,'PRODUCT','Salwar Kamiz',1,220000,220000,'2026-09-17 00:16:03.305991',150000),('e95cfcc4-6308-49c0-8886-9637b0075c27','82ba4ae8-5d15-45c7-baf8-1cfebfc89d0b',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',2,100000,200000,'2026-09-30 19:51:08.249701',0),('eaa05c82-a74c-4b4e-a0d1-7888c9714051','63cddfaf-3006-4efa-bfa9-295cfc7dfd93',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',2,40000,80000,'2026-09-30 18:30:14.535309',0),('eae98677-9706-4e24-815c-5640f81a4bb2','0a2e1848-1062-49d2-80b7-b71a75460fad',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-17 03:45:13.021751',0),('ec377652-1054-4d69-b4a0-1c6e58a2d253','897d80be-00c7-499c-b6b6-cbc5fc454adc',NULL,'c7bf60b5-19db-4820-a4a1-b14fb8e71064',NULL,'SERVICE','Hair Shampoo',1,20000,20000,'2026-09-22 15:01:30.931041',0),('ece2d5c1-e6a9-40ce-8fdf-f93ce79bb0f5','1a6acce4-019e-4c82-be76-235eddae29df','f81330ad-0b4c-44ac-ace1-ee3fe54f32eb',NULL,NULL,'PRODUCT','Rexona Vitamin + Bright',1,25000,25000,'2026-09-15 11:37:33.363138',22000),('eefd0a91-c31c-4d35-b77a-f67c1abd2148','d3e915e4-5e59-40b6-9d46-c6872c79d196',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-17 02:53:37.555871',0),('efdadf61-cfec-48fd-9f9a-7f63bc48a75f','35007418-1eed-4619-8aaa-438cd848618c',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:27:51.071659',0),('f0d28ccc-ba85-4a4b-86f5-f3aa93b93335','06d30257-aefd-4961-8fd8-6eebf3fa68a5',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-30 23:38:47.176064',0),('f247f3ce-135f-4f92-9286-458a31ee3aa4','bff16f4b-be0e-43eb-baab-1ec512e464de','65af649e-d5c0-43f5-b91d-a8a12b2eb755',NULL,NULL,'PRODUCT','Zamdani',1,250000,250000,'2026-09-16 23:44:00.214994',200000),('f35759f4-f5bd-4db1-9e99-4c0168d8f090','184a543d-c015-4e90-bae8-ae573a205264',NULL,'4c72bab3-b4e0-498b-b2d6-1c8e899b1c59',NULL,'SERVICE','Hair Blow Dry',1,30000,30000,'2026-09-30 18:35:43.231716',0),('f41aaad6-6e6d-4a5d-8dc6-3f461842bb77','0097abce-86a5-4096-8ec8-53ff784587ce',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',2,40000,80000,'2026-09-17 03:42:19.960151',0),('f7d69196-083e-40fa-bf78-0d6c2549341c','a02d6a81-eb55-4c84-b3eb-2918c3949ba1',NULL,'7fb37859-8333-401a-ad69-484b5de50782',NULL,'SERVICE','Face Booster Serum',1,40000,40000,'2026-09-17 03:43:00.622418',0),('fbcd0c67-898a-4b3e-98b6-7f59927eb522','9b8d49da-148c-4352-ba70-fd04ff6edb8b',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 04:01:42.977180',0),('fda3eb0d-d970-4ac3-8783-22a384f97e7f','55389639-2f4f-41d7-8a25-59d641760726',NULL,'d5b1e0e1-ed57-4aae-84d4-7e9f5bbc9ee2',NULL,'SERVICE','Hydra Facial',1,100000,100000,'2026-09-17 03:13:27.327981',0),('fef13b3f-fdc5-4731-9597-4570a78e23dd','ba96112b-bf7a-4451-b5b2-887fb925994c',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-22 23:06:35.123624',0),('ff205bec-7804-4b7d-8486-40842c7af970','55389639-2f4f-41d7-8a25-59d641760726',NULL,'aebe058f-8ab3-49e8-8a79-ae9f1a30b97f',NULL,'SERVICE','Bridal Facial',1,50000,50000,'2026-09-17 03:13:27.315905',0);
/*!40000 ALTER TABLE `transaction_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `customer_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal_minor` bigint unsigned NOT NULL,
  `discount_minor` bigint unsigned NOT NULL DEFAULT '0',
  `vat_rate_percent` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `vat_minor` bigint unsigned NOT NULL DEFAULT '0',
  `total_minor` bigint unsigned NOT NULL,
  `cash_received_minor` bigint unsigned NOT NULL,
  `change_minor` bigint unsigned NOT NULL,
  `cashier` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_of_goods_sold_minor` bigint unsigned NOT NULL DEFAULT '0',
  `reward_discount_minor` bigint unsigned NOT NULL DEFAULT '0',
  `reward_points_redeemed` int unsigned NOT NULL DEFAULT '0',
  `loyalty_points_earned` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_transactions_invoice` (`invoice_id`),
  KEY `idx_transactions_customer` (`customer_id`),
  CONSTRAINT `fk_transactions_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES ('0097abce-86a5-4096-8ec8-53ff784587ce','DM-20260917-0007','2026-09-17 03:42:19.945358',NULL,250000,0,0.00,0,250000,250000,0,'staff',0,0,0,0),('06d30257-aefd-4961-8fd8-6eebf3fa68a5','DM-20260930-0008','2026-09-30 23:38:47.165707',NULL,330000,5000,0.00,0,325000,350000,25000,'admin',0,5000,50,33),('0a2e1848-1062-49d2-80b7-b71a75460fad','DM-20260917-0010','2026-09-17 03:45:13.014495',NULL,240000,0,0.00,0,240000,240000,0,'staff',0,0,0,0),('0e91632d-61c8-49e0-aab5-da1bbd0b9162','DM-20260916-0003','2026-09-16 23:21:54.389154',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('0faba69f-209e-4423-b40c-845084c7c791','DM-20260916-0005','2026-09-16 23:26:46.994569',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('140d79b5-98c9-4835-aec7-9511ac5e596e','DM-20260916-0004','2026-09-16 23:23:05.986280',NULL,100000,0,0.00,0,100000,100000,0,'admin',44000,0,0,0),('18285d88-c997-4bff-b3d1-7e1c3bbf986f','DM-20260916-0001','2026-09-16 22:52:21.171747',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('184a543d-c015-4e90-bae8-ae573a205264','DM-20260930-0003','2026-09-30 18:35:43.216960',NULL,240000,10000,15.00,36000,266000,300000,34000,'admin',0,0,0,0),('1a6acce4-019e-4c82-be76-235eddae29df','DM-20260915-0001','2026-09-15 11:37:33.346138','aae6d71a-2e5a-4edc-bfce-d15d0ec1a64c',25000,0,0.00,0,25000,25000,0,'admin',22000,0,0,2),('23c6d836-44b5-4781-9101-7d7fb17084ac','DM-20260930-0005','2026-09-30 21:00:00.076385',NULL,240000,20000,0.00,0,220000,250000,30000,'admin',0,0,0,0),('2e1c2891-7bfb-427f-97ce-d8e5a0cde2dd','DM-20260930-0006','2026-09-30 22:23:31.712856',NULL,210000,10000,0.00,0,200000,200000,0,'admin',0,0,0,0),('300d132d-9cb8-400f-92f9-7a573b2616dd','DM-20260917-0005','2026-09-17 03:16:38.337704',NULL,210000,0,0.00,0,210000,210000,0,'staff',0,0,0,0),('35007418-1eed-4619-8aaa-438cd848618c','DM-20260917-0006','2026-09-17 03:27:51.055269',NULL,210000,0,0.00,0,210000,210000,0,'staff',0,0,0,0),('3640abf7-9121-414a-841c-e27c0ee04172','DM-20260915-0002','2026-09-15 13:20:54.033900',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('385fbf72-9db6-4180-b044-147fbc46a473','DM-20260917-0001','2026-09-17 00:16:03.287875',NULL,545000,10000,15.00,81750,616750,700000,83250,'admin',372000,0,0,0),('55389639-2f4f-41d7-8a25-59d641760726','DM-20260917-0004','2026-09-17 03:13:27.303301',NULL,240000,0,0.00,0,240000,240000,0,'staff',0,0,0,0),('556bdfcd-2618-41ff-86cc-edab327513e1','DM-20260917-0002','2026-09-17 01:34:55.448102',NULL,220000,0,0.00,0,220000,220000,0,'staff',0,0,0,0),('57915558-aba9-43e3-8e20-5e9d4bf888b1','DM-20260930-0001','2026-09-30 18:21:40.620799',NULL,240000,0,0.00,0,240000,240000,0,'admin',0,0,0,0),('63cddfaf-3006-4efa-bfa9-295cfc7dfd93','DM-20260930-0002','2026-09-30 18:30:14.520250',NULL,280000,5000,0.00,0,275000,300000,25000,'admin',0,0,0,0),('82ba4ae8-5d15-45c7-baf8-1cfebfc89d0b','DM-20260930-0004','2026-09-30 19:51:08.222182',NULL,290000,10000,0.00,0,280000,300000,20000,'admin',0,0,0,0),('897d80be-00c7-499c-b6b6-cbc5fc454adc','DM-20260922-0001','2026-09-22 15:01:30.908343',NULL,140000,0,0.00,0,140000,140000,0,'admin',0,0,0,0),('9b8d49da-148c-4352-ba70-fd04ff6edb8b','DM-20260917-0011','2026-09-17 04:01:42.965482',NULL,210000,0,0.00,0,210000,210000,0,'staff',0,0,0,0),('9dbfa181-3b79-4f15-8cff-2d0afce64ccc','DM-20260917-0009','2026-09-17 03:44:27.190115',NULL,210000,0,0.00,0,210000,210000,0,'staff',0,0,0,0),('a02d6a81-eb55-4c84-b3eb-2918c3949ba1','DM-20260917-0008','2026-09-17 03:43:00.616677',NULL,260000,0,0.00,0,260000,260000,0,'staff',0,0,0,0),('b481eba8-851b-4ad6-80ee-8f2bcae7d1a3','DM-20260916-0006','2026-09-16 23:27:41.127211',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('ba96112b-bf7a-4451-b5b2-887fb925994c','DM-20260922-0002','2026-09-22 23:06:35.111071','aae6d71a-2e5a-4edc-bfce-d15d0ec1a64c',110000,0,0.00,0,110000,150000,40000,'admin',0,0,0,11),('bff16f4b-be0e-43eb-baab-1ec512e464de','DM-20260916-0008','2026-09-16 23:44:00.201819',NULL,545000,0,0.00,0,545000,545000,0,'admin',372000,0,0,0),('d0b189e3-227f-415b-97ee-1ad345bc16e8','DM-20260916-0007','2026-09-16 23:28:23.948115',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('d3e915e4-5e59-40b6-9d46-c6872c79d196','DM-20260917-0003','2026-09-17 02:53:37.532158',NULL,240000,0,0.00,0,240000,240000,0,'staff',0,0,0,0),('db1d87f7-2a54-4753-9f72-f467e9d25794','DM-20260916-0002','2026-09-16 23:00:27.273139',NULL,75000,0,0.00,0,75000,75000,0,'admin',22000,0,0,0),('fca398ff-21a9-4653-b1b7-244b15e55206','DM-20260930-0007','2026-09-30 23:35:53.252579',NULL,220000,0,0.00,0,220000,250000,30000,'admin',0,0,0,22);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('ADMIN','STAFF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STAFF',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('95fa61ee-aefa-11f1-ac2a-f851aa63f293','admin','$2b$10$i2OuFfefdR/2z.I9FpYOVutDupwDHnKMkUipqdVLJ3Pg59jtRGsKm','Administrator','ADMIN',1,'2026-09-13 04:37:50.642742','2026-09-13 04:37:50.642742'),('d7b9aa16-b00f-11f1-ac2a-f851aa63f293','staff','$2b$10$1UL3Iz2QJmM0YLgeuWlf9eyy9E5kCfKGaWFxJuag5q96af31GyMle','Staff Member','STAFF',1,'2026-09-14 13:42:31.543380','2026-09-14 13:42:31.543380');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-01  0:42:13
